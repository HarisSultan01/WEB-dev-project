<?php
include("includes/db_connect.php");
include("includes/header.php");
?>

<div class="container mt-4">
    <h2>Welcome Guest</h2>
    <p>Explore societies and upcoming events. <a href="login.php">Login</a> or <a href="signup.php">Signup</a> for more features.</p>

    <!-- List Societies -->
    <h3>University Societies</h3>
    <div class="row">
    <?php
    $stmt = $conn->prepare("SELECT * FROM societies");
    if ($stmt === false) {
        error_log("Prepare failed for societies fetch: " . $conn->error);
        echo "<p class='text-danger'>Error fetching societies.</p>";
    } else {
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Check if logo exists, otherwise use a placeholder
                $logo_path = !empty($row['logo']) && file_exists("images/" . $row['logo']) ? "images/" . $row['logo'] : "https://placehold.co/150x150/cccccc/000000?text=No+Logo";
                echo '<div class="col-12 col-md-4 mb-3">';
                echo '<div class="card h-100">'; // Added h-100 for consistent card height
                echo '<img src="' . htmlspecialchars($logo_path) . '" class="card-img-top p-3" alt="' . htmlspecialchars($row['name']) . ' Logo" style="max-height: 150px; object-fit: contain;">'; // Added styling for better image display
                echo '<div class="card-body">';
                echo '<h5 class="card-title">' . htmlspecialchars($row['name']) . '</h5>';
                echo '<p class="card-text">' . htmlspecialchars($row['description']) . '</p>';
                echo '<a href="society.php?id=' . htmlspecialchars($row['society_id']) . '" class="btn btn-primary">View Society</a>';
                echo '</div></div></div>';
            }
        } else {
            echo "<p>No societies found.</p>";
        }
        $stmt->close();
    }
    ?>
    </div>

    <!-- List Approved Events -->
    <h3 class="mt-5">Upcoming Events</h3>
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Society</th> <!-- New column for Society Name -->
                    <th>Date</th>
                    <th>Time</th>
                    <th>Venue</th>
                    <th>Poster</th> <!-- Added Poster column -->
                </tr>
            </thead>
            <tbody>
                <?php
                // Modified query to include society name and poster
                $stmt = $conn->prepare("SELECT e.title, e.date, e.time, e.venue, e.poster, s.name as society_name 
                                        FROM events e 
                                        INNER JOIN event_requests r ON e.event_id = r.event_id 
                                        INNER JOIN societies s ON e.society_id = s.society_id 
                                        WHERE r.status = 'Approved' AND e.date >= CURDATE() ORDER BY e.date ASC, e.time ASC"); // Filter future events, order by date/time
                if ($stmt === false) {
                    error_log("Prepare failed for events fetch: " . $conn->error);
                    echo "<tr><td colspan='6' class='text-danger'>Error fetching events.</td></tr>";
                } else {
                    $stmt->execute();
                    $result = $stmt->get_result();
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            // Check if poster exists, otherwise use a placeholder
                            $poster_path = !empty($row['poster']) && file_exists("images/" . $row['poster']) ? "images/" . $row['poster'] : "https://placehold.co/50x50/cccccc/000000?text=No+Poster";
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['title']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['society_name']) . "</td>"; // Display society name
                            echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['time']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['venue']) . "</td>";
                            echo "<td><img src='" . htmlspecialchars($poster_path) . "' alt='Event Poster' width='50'></td>"; // Display poster
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6'>No upcoming approved events found.</td></tr>";
                    }
                    $stmt->close();
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php include("includes/footer.php"); ?>
