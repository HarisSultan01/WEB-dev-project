</div> <!-- Close container -->
<footer class="bg-light py-3 mt-5">
    <div class="container text-center">
        <small>&copy; <?php echo date('Y'); ?> University Societies Management System</small>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Add analytics script here if needed -->
</body>
</html>