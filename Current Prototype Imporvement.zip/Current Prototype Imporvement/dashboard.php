<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$role = $_SESSION['role'];
if ($role == 'Admin') {
    header("Location: admin_panel.php");
} elseif ($role == 'President') {
    header("Location: president_panel.php");
} elseif ($role == 'Moderator') {
    header("Location: moderator_panel.php");
} else {
    header("Location: guest_view.php"); // Default for undefined roles
}
exit();
?>