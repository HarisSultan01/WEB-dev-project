<?php
session_start();
include("includes/db_connect.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Moderator') {
    header("Location: login.php");
    exit();
}

if (isset($_GET['approve'])) {
    $event_id = intval($_GET['approve']);
    $stmt = $conn->prepare("UPDATE event_requests SET status = 'Approved' WHERE event_id = ?");
    $stmt->bind_param("i", $event_id);
    $stmt->execute();
    $stmt->close();
} elseif (isset($_GET['reject'])) {
    $event_id = intval($_GET['reject']);
    $stmt = $conn->prepare("UPDATE event_requests SET status = 'Rejected' WHERE event_id = ?");
    $stmt->bind_param("i", $event_id);
    $stmt->execute();
    $stmt->close();
}
?>

<?php include("includes/header.php"); ?>
<h2>Moderator Panel</h2>
<p>Welcome, <strong><?php echo $_SESSION['name']; ?></strong> (Moderator)</p>
<a href="logout.php" class="btn btn-danger mb-3">Logout</a>

<!-- Pending Event Requests -->
<h4>Pending Event Requests</h4>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Event Title</th>
            <th>Description</th>
            <th>Date</th>
            <th>Time</th>
            <th>Venue</th>
            <th>Poster</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $stmt = $conn->prepare("SELECT e.event_id, e.title, e.description, e.date, e.time, e.venue, e.poster FROM events e INNER JOIN event_requests r ON e.event_id = r.event_id WHERE r.status = 'Pending'");
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>".$row['event_id']."</td>";
            echo "<td>".htmlspecialchars($row['title'])."</td>";
            echo "<td>".htmlspecialchars($row['description'])."</td>";
            echo "<td>".htmlspecialchars($row['date'])."</td>";
            echo "<td>".htmlspecialchars($row['time'])."</td>";
            echo "<td>".htmlspecialchars($row['venue'])."</td>";
            echo "<td><img src='images/".htmlspecialchars($row['poster'])."' width='50'></td>";
            echo "<td>
                    <a href='?approve=".$row['event_id']."' class='btn btn-success btn-sm' onclick='return confirm(\"Approve this event?\");'>Approve</a>
                    <a href='?reject=".$row['event_id']."' class='btn btn-danger btn-sm' onclick='return confirm(\"Reject this event?\");'>Reject</a>
                  </td>";
            echo "</tr>";
        }
        $stmt->close();
        ?>
    </tbody>
</table>

<?php include("includes/footer.php"); ?>