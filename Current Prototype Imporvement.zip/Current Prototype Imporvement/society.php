<?php
include("includes/db_connect.php");
include("includes/header.php");

if (!isset($_GET['id'])) {
    echo "<p>Invalid society.</p>";
    include("includes/footer.php");
    exit();
}

$society_id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM societies WHERE society_id = ?");
$stmt->bind_param("i", $society_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    echo "<p>Society not found.</p>";
    include("includes/footer.php");
    exit();
}
$society = $result->fetch_assoc();
$stmt->close();
?>

<h2><?php echo htmlspecialchars($society['name']); ?></h2>
<img src="images/<?php echo file_exists("images/" . $society['logo']) ? htmlspecialchars($society['logo']) : "default.png"; ?>" width="100" alt="Society Logo">
<p><?php echo htmlspecialchars($society['description']); ?></p>

<!-- Events -->
<h4>Upcoming Events</h4>
<ul>
<?php
$stmt = $conn->prepare("SELECT e.title, e.date, e.venue FROM events e INNER JOIN event_requests r ON e.event_id = r.event_id WHERE e.created_by IN (SELECT user_id FROM society_members WHERE society_id = ?) AND r.status = 'Approved'");
$stmt->bind_param("i", $society_id);
$stmt->execute();
$events = $stmt->get_result();
while ($row = $events->fetch_assoc()) {
    echo "<li>" . htmlspecialchars($row['title']) . " on " . htmlspecialchars($row['date']) . " at " . htmlspecialchars($row['venue']) . "</li>";
}
$stmt->close();
?>
</ul>

<!-- Members -->
<h4>Members</h4>
<ul>
<?php
$stmt = $conn->prepare("SELECT u.name FROM users u INNER JOIN society_members sm ON u.user_id = sm.user_id WHERE sm.society_id = ?");
$stmt->bind_param("i", $society_id);
$stmt->execute();
$members = $stmt->get_result();
while ($row = $members->fetch_assoc()) {
    echo "<li>" . htmlspecialchars($row['name']) . "</li>";
}
$stmt->close();
?>
</ul>

<?php include("includes/footer.php"); ?>