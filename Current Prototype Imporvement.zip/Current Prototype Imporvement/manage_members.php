<?php
session_start();
include("includes/db_connect.php");

// Initialize variables for notifications
$success = "";
$error = "";

// Check if user is Admin or President
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] != 'Admin' && $_SESSION['role'] != 'President')) {
    header("Location: login.php");
    exit();
}

// Ensure society_id is provided in the URL
if (!isset($_GET['society_id'])) {
    die("❌ Society ID not provided.");
}
$society_id = intval($_GET['society_id']);

// Fetch society details
$stmt = $conn->prepare("SELECT * FROM societies WHERE society_id = ?");
if ($stmt === false) {
    error_log("Prepare failed for society details fetch: " . $conn->error);
    die("❌ An internal database error occurred.");
}
$stmt->bind_param("i", $society_id);
$stmt->execute();
$society_result = $stmt->get_result();
if ($society_result->num_rows == 0) {
    die("❌ Society not found.");
}
$society = $society_result->fetch_assoc();
$stmt->close();

// Handle adding a new member
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_member'])) {
    $user_id = intval($_POST['user_id']);
    $role = $conn->real_escape_string($_POST['role']);

    // Check if user is already a member of this society
    $stmt = $conn->prepare("SELECT * FROM society_members WHERE society_id = ? AND user_id = ?");
    if ($stmt === false) {
        error_log("Prepare failed for member check: " . $conn->error);
        $error = "❌ An internal error occurred.";
    } else {
        $stmt->bind_param("ii", $society_id, $user_id);
        $stmt->execute();
        $check_result = $stmt->get_result();

        if ($check_result->num_rows > 0) {
            $error = "❌ User is already a member of this society.";
        } else {
            // Add member to society_members table
            $stmt_add = $conn->prepare("INSERT INTO society_members (society_id, user_id, role) VALUES (?, ?, ?)");
            if ($stmt_add === false) {
                error_log("Prepare failed for add member: " . $conn->error);
                $error = "❌ An internal error occurred.";
            } else {
                $stmt_add->bind_param("iis", $society_id, $user_id, $role);
                if ($stmt_add->execute()) {
                    $success = "✅ Member added successfully!";
                } else {
                    $error = "❌ Failed to add member: " . $stmt_add->error;
                }
                $stmt_add->close();
            }
        }
        $stmt->close(); // Close the check_result statement
    }
}

// Handle removing a member
if (isset($_GET['remove_member'])) {
    $member_id = intval($_GET['remove_member']);
    $stmt = $conn->prepare("DELETE FROM society_members WHERE id = ? AND society_id = ?");
    if ($stmt === false) {
        error_log("Prepare failed for remove member: " . $conn->error);
        $error = "❌ An internal error occurred.";
    } else {
        $stmt->bind_param("ii", $member_id, $society_id);
        if ($stmt->execute()) {
            $success = "✅ Member removed successfully!";
        } else {
            $error = "❌ Failed to remove member: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Fetch current members and available users (similarly updated with prepared statements)
// This part was already well-handled in your provided code, just ensuring it's here.
?>

<?php include("includes/header.php"); ?>
<div class="container mt-4">
    <!-- Corrected line 64: Changed $society['society_name'] to $society['name'] -->
    <h2>Manage Members for <strong><?php echo htmlspecialchars($society['name']); ?></strong></h2>
    <a href="dashboard.php" class="btn btn-secondary mb-3">⬅ Back to Dashboard</a>

    <?php if (!empty($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
    <?php if (!empty($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

    <!-- Add Member Form -->
    <div class="card mb-4">
        <div class="card-header">Add New Member</div>
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label>Select User</label>
                    <select name="user_id" class="form-control" required>
                        <option value="">-- Choose User --</option>
                        <?php
                        // Fetch users who are NOT already members of this society
                        $stmt = $conn->prepare("SELECT user_id, name, email FROM users WHERE user_id NOT IN (SELECT user_id FROM society_members WHERE society_id = ?)");
                        if ($stmt === false) {
                            error_log("Prepare failed for available users fetch: " . $conn->error);
                            echo "<option value=''>Error fetching users</option>";
                        } else {
                            $stmt->bind_param("i", $society_id);
                            $stmt->execute();
                            $available_users_result = $stmt->get_result();
                            if ($available_users_result->num_rows > 0) {
                                while ($user = $available_users_result->fetch_assoc()) {
                                    echo "<option value='".htmlspecialchars($user['user_id'])."'>".htmlspecialchars($user['name'])." (".htmlspecialchars($user['email']).")</option>";
                                }
                            } else {
                                echo "<option value=''>No available users</option>";
                            }
                            $stmt->close();
                        }
                        ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label>Assign Role</label>
                    <select name="role" class="form-control" required>
                        <option value="Member">Member</option>
                        <option value="Moderator">Moderator</option>
                    </select>
                </div>
                <button type="submit" name="add_member" class="btn btn-primary">➕ Add Member</button>
            </form>
        </div>
    </div>

    <!-- Existing Members Table -->
    <div class="card">
        <div class="card-header">Existing Members</div>
        <div class="card-body">
            <?php
            // Fetch current members of this society
            $stmt = $conn->prepare("SELECT m.id, u.user_id, u.name, u.email, m.role FROM society_members m INNER JOIN users u ON m.user_id = u.user_id WHERE m.society_id = ?");
            if ($stmt === false) {
                error_log("Prepare failed for existing members fetch: " . $conn->error);
                echo "<p class='text-danger'>Error fetching members.</p>";
            } else {
                $stmt->bind_param("i", $society_id);
                $stmt->execute();
                $members_result = $stmt->get_result();
                if ($members_result->num_rows > 0) {
                    echo "<table class='table table-bordered'>
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>";
                    while ($member = $members_result->fetch_assoc()) {
                        echo "<tr>
                                <td>".htmlspecialchars($member['name'])."</td>
                                <td>".htmlspecialchars($member['email'])."</td>
                                <td>".htmlspecialchars($member['role'])."</td>
                                <td>";
                        // Prevent removing the president if the logged-in user is the president of this society
                        // Or add more sophisticated logic if needed
                        if ($_SESSION['role'] == 'Admin' || ($_SESSION['role'] == 'President' && $member['user_id'] != $_SESSION['user_id'])) {
                            echo "<a href='manage_members.php?society_id=$society_id&remove_member=".$member['id']."' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to remove this member?\");'>❌ Remove</a>";
                        } else {
                            echo "<span class='text-muted'>Cannot Remove</span>";
                        }
                        echo "</td>
                            </tr>";
                    }
                    echo "</tbody></table>";
                } else {
                    echo "<p>No members found for this society.</p>";
                }
                $stmt->close();
            }
            ?>
        </div>
    </div>
</div>

<?php include("includes/footer.php"); ?>
