<?php
session_start();
include("includes/db_connect.php");

// CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("Invalid CSRF token.");
    }

    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT user_id, name, role, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['role'] = $user['role'];
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "No user found with that email.";
    }
    $stmt->close();
}
?>

<?php include("includes/header.php"); ?>
<h2>Login</h2>
<?php if (!empty($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
<?php if (isset($_GET['success'])) echo "<div class='alert alert-success'>Signup successful! Please login.</div>"; ?>
<form method="POST">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
    <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email" class="form-control" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$">
    </div>
    <div class="mb-3">
        <label>Password</label>
        <input type="password" name="password" class="form-control" required minlength="8">
    </div>
    <div class="d-flex gap-2 mb-3"> <!-- Flexbox to align buttons side by side -->
        <button type="submit" class="btn btn-primary">Login</button>
        <a href="signup.php" class="btn btn-success">Sign Up</a>
    </div>
    <a href="guest_view.php" class="btn btn-secondary">Continue as Guest</a>
</form>
<?php include("includes/footer.php"); ?>