<?php
session_start();
include("includes/db_connect.php");

// ✅ Check if user is Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

if (isset($_GET['action']) && isset($_GET['request_id'])) {
    $action = $_GET['action'];
    $request_id = intval($_GET['request_id']);

    // Fetch request details
    $stmt = $conn->prepare("SELECT user_id, requested_role FROM role_requests WHERE request_id = ? AND status = 'Pending'");
    $stmt->bind_param("i", $request_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $request = $result->fetch_assoc();
    $stmt->close();

    if ($request) {
        $user_id = $request['user_id'];
        $requested_role = $request['requested_role'];

        if ($action === 'approve') {
            // Update user's role
            $update_user_stmt = $conn->prepare("UPDATE users SET role = ? WHERE user_id = ?");
            $update_user_stmt->bind_param("si", $requested_role, $user_id);
            
            if ($update_user_stmt->execute()) {
                // Update request status
                $update_request_stmt = $conn->prepare("UPDATE role_requests SET status = 'Approved' WHERE request_id = ?");
                $update_request_stmt->bind_param("i", $request_id);
                $update_request_stmt->execute();
                $update_request_stmt->close();

                $_SESSION['success_message'] = "✅ Role request approved and user role updated successfully!";
            } else {
                $_SESSION['error_message'] = "❌ Error updating user role: " . $update_user_stmt->error;
            }
            $update_user_stmt->close();

        } elseif ($action === 'reject') {
            // Update request status to Rejected
            $update_request_stmt = $conn->prepare("UPDATE role_requests SET status = 'Rejected' WHERE request_id = ?");
            $update_request_stmt->bind_param("i", $request_id);
            
            if ($update_request_stmt->execute()) {
                $_SESSION['success_message'] = "✅ Role request rejected successfully!";
            } else {
                $_SESSION['error_message'] = "❌ Error rejecting request: " . $update_request_stmt->error;
            }
            $update_request_stmt->close();
        }
    } else {
        $_SESSION['error_message'] = "❌ Invalid request or request already processed.";
    }
} else {
    $_SESSION['error_message'] = "❌ Invalid action.";
}

// Redirect back to admin panel
header("Location: admin_panel.php");
exit();
?>
