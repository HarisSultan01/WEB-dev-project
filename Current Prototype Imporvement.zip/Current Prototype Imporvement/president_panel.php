<?php
session_start();
include("includes/db_connect.php"); // Ensure this path is correct

// Initialize variables for notifications
$success = "";
$error = "";
$assigned_society = null; // Changed from $society_id and $society_name for consistency with previous suggestion
$society_name = "N/A"; // Default value in case no society is found

// Check if user is President
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'President') {
    header("Location: login.php");
    exit();
}

// Validate database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- Core Logic: Determine the president's society by checking the 'societies' table ---
// This is updated to match how presidents are assigned in admin_panel.php
$stmt_society_check = $conn->prepare("SELECT society_id, name, description, logo FROM societies WHERE president_id = ?");
if ($stmt_society_check === false) {
    // Log the error for debugging purposes instead of dying abruptly
    error_log("Prepare failed for societies table check: " . $conn->error);
    $error = "❌ An internal database error occurred while checking society assignment. Please try again later.";
} else {
    $stmt_society_check->bind_param("i", $_SESSION['user_id']);
    $stmt_society_check->execute();
    $result_society_check = $stmt_society_check->get_result();

    if ($result_society_check->num_rows > 0) {
        $assigned_society = $result_society_check->fetch_assoc();
        $society_name = $assigned_society['name']; // Set society name for display
        $society_id = $assigned_society['society_id']; // Set society_id for event management
    } else {
        $error = "❌ You are not assigned as a president of any society. Please contact an administrator.";
        $society_id = null; // Ensure society_id is null if no society is found
    }
    $stmt_society_check->close();
}

// Check for success/error messages from other pages (e.g., handle_request.php)
// Merge these with existing $success and $error variables
$session_success_message = $_SESSION['success_message'] ?? '';
$session_error_message = $_SESSION['error_message'] ?? '';

if (!empty($session_success_message)) {
    $success .= (empty($success) ? "" : "<br>") . $session_success_message;
}
if (!empty($session_error_message)) {
    $error .= (empty($error) ? "" : "<br>") . $session_error_message;
}

// Clear session messages after displaying
unset($_SESSION['success_message']);
unset($_SESSION['error_message']);


// --- Handle Event Addition ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_event']) && empty($error)) {
    // Only proceed if a society_id was successfully determined
    if ($society_id === null) {
        $error = "❌ Cannot add event: You are not assigned to a society.";
    } else {
        $title = trim($conn->real_escape_string($_POST['title']));
        $description = trim($conn->real_escape_string($_POST['description']));
        $date = $_POST['date'];
        $time = $_POST['time'];
        $venue = trim($conn->real_escape_string($_POST['venue']));
        $poster = $_FILES['poster']['name'];
        $target = "images/" . basename($poster);

        $today = date('Y-m-d');
        if ($date <= $today) {
            $error = "❌ Event date must be in the future.";
        } else {
            // Check for existing event on the same date for this president's society
            $stmt_check_event = $conn->prepare("SELECT event_id FROM events WHERE date = ? AND created_by = ? AND society_id = ?"); // Added society_id to check
            if ($stmt_check_event === false) {
                error_log("Prepare failed for event date check: " . $conn->error);
                $error = "❌ An internal error occurred.";
            } else {
                $stmt_check_event->bind_param("sii", $date, $_SESSION['user_id'], $society_id); // Bind society_id
                $stmt_check_event->execute();
                $check_result = $stmt_check_event->get_result();

                if ($check_result->num_rows > 0) {
                    $error = "❌ An event is already scheduled on " . htmlspecialchars($date) . " for your society. Please choose another date.";
                } else {
                    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
                    // Basic file validation
                    if (!empty($poster) && in_array($_FILES['poster']['type'], $allowed_types) && $_FILES['poster']['size'] < 5000000) {
                        if (move_uploaded_file($_FILES['poster']['tmp_name'], $target)) {
                            // Insert into events table
                            $stmt_insert_event = $conn->prepare("INSERT INTO events (title, description, date, time, venue, poster, created_by, society_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                            if ($stmt_insert_event === false) {
                                error_log("Prepare failed for insert event: " . $conn->error);
                                $error = "❌ An internal error occurred.";
                            } else {
                                $stmt_insert_event->bind_param("ssssssii", $title, $description, $date, $time, $venue, $poster, $_SESSION['user_id'], $society_id);
                                if ($stmt_insert_event->execute()) {
                                    $event_id = $conn->insert_id;
                                    // Insert into event_requests table
                                    $stmt_event_request = $conn->prepare("INSERT INTO event_requests (event_id, status) VALUES (?, 'Pending')");
                                    if ($stmt_event_request === false) {
                                        error_log("Prepare failed for event_requests: " . $conn->error);
                                        $error = "❌ An internal error occurred.";
                                    } else {
                                        $stmt_event_request->bind_param("i", $event_id);
                                        if ($stmt_event_request->execute()) {
                                            $success = "✅ Event added successfully and submitted for approval!";
                                        } else {
                                            $error = "❌ Error submitting event for approval: " . $stmt_event_request->error;
                                        }
                                        $stmt_event_request->close();
                                    }
                                } else {
                                    $error = "❌ Error adding event: " . $stmt_insert_event->error;
                                }
                                $stmt_insert_event->close();
                            }
                        } else {
                            $error = "❌ Failed to upload poster.";
                        }
                    } else {
                        $error = "❌ Invalid file type or size for poster. Use JPEG, PNG, or GIF (max 5MB).";
                    }
                }
                $stmt_check_event->close();
            }
        }
    }
}


// --- Handle Event Update ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_event']) && empty($error)) {
    // Only proceed if a society_id was successfully determined
    if ($society_id === null) {
        $error = "❌ Cannot update event: You are not assigned to a society.";
    } else {
        $event_id = intval($_POST['event_id']);
        $title = trim($conn->real_escape_string($_POST['title']));
        $description = trim($conn->real_escape_string($_POST['description']));
        $date = $_POST['date'];
        $time = $_POST['time'];
        $venue = trim($conn->real_escape_string($_POST['venue']));
        $poster = $_FILES['poster']['name'];
        $target = "images/" . basename($poster);

        $today = date('Y-m-d');
        if ($date <= $today) {
            $error = "❌ Event date must be in the future.";
        } else {
            // Verify event belongs to this president and society
            $stmt_verify_event = $conn->prepare("SELECT event_id FROM events WHERE event_id = ? AND created_by = ? AND society_id = ?"); // Added society_id
            if ($stmt_verify_event === false) {
                error_log("Prepare failed for event verification: " . $conn->error);
                $error = "❌ An internal error occurred.";
            } else {
                $stmt_verify_event->bind_param("iii", $event_id, $_SESSION['user_id'], $society_id); // Bind society_id
                $stmt_verify_event->execute();
                if ($stmt_verify_event->get_result()->num_rows == 0) {
                    $error = "❌ You do not have permission to edit this event or the event does not exist.";
                } else {
                    $update_sql = "";
                    $bind_types = "";
                    $bind_params = [];

                    if (!empty($poster)) {
                        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
                        if (in_array($_FILES['poster']['type'], $allowed_types) && $_FILES['poster']['size'] < 5000000) {
                            if (move_uploaded_file($_FILES['poster']['tmp_name'], $target)) {
                                $update_sql = "UPDATE events SET title = ?, description = ?, date = ?, time = ?, venue = ?, poster = ? WHERE event_id = ?";
                                $bind_types = "ssssssi";
                                $bind_params = [&$title, &$description, &$date, &$time, &$venue, &$poster, &$event_id];
                            } else {
                                $error = "❌ Failed to upload new poster.";
                            }
                        } else {
                            $error = "❌ Invalid file type or size for poster. Use JPEG, PNG, or GIF (max 5MB).";
                        }
                    } else {
                        $update_sql = "UPDATE events SET title = ?, description = ?, date = ?, time = ?, venue = ? WHERE event_id = ?";
                        $bind_types = "sssssi";
                        $bind_params = [&$title, &$description, &$date, &$time, &$venue, &$event_id];
                    }

                    if (empty($error) && !empty($update_sql)) {
                        $stmt_update_event = $conn->prepare($update_sql);
                        if ($stmt_update_event === false) {
                            error_log("Prepare failed for update event: " . $conn->error);
                            $error = "❌ An internal error occurred during update preparation.";
                        } else {
                            // Use call_user_func_array to bind parameters dynamically
                            call_user_func_array([$stmt_update_event, 'bind_param'], array_merge([$bind_types], $bind_params));

                            if ($stmt_update_event->execute()) {
                                $success = "✅ Event updated successfully!";
                            } else {
                                $error = "❌ Error updating event: " . $stmt_update_event->error;
                            }
                            $stmt_update_event->close();
                        }
                    }
                }
                $stmt_verify_event->close();
            }
        }
    }
}


// --- Fetch events for the president's society ---
$events = null;
if ($society_id !== null) { // Only fetch events if a society is assigned
    $stmt_fetch_events = $conn->prepare("SELECT e.event_id, e.title, e.description, e.date, e.time, e.venue, e.poster, r.status
                                         FROM events e
                                         LEFT JOIN event_requests r ON e.event_id = r.event_id
                                         WHERE e.created_by = ? AND e.society_id = ? ORDER BY e.date DESC"); // Add society_id filter and order
    if ($stmt_fetch_events === false) {
        error_log("Prepare failed for fetching events: " . $conn->error);
        $error = "❌ An internal error occurred while fetching events.";
    } else {
        $stmt_fetch_events->bind_param("ii", $_SESSION['user_id'], $society_id);
        $stmt_fetch_events->execute();
        $events = $stmt_fetch_events->get_result();
        $stmt_fetch_events->close();
    }
}

include("includes/header.php");
?>
<div class="container mt-4">
    <h2>🏛️ President Panel - <?php echo htmlspecialchars($society_name); ?></h2>
    <p>Welcome, <strong><?php echo htmlspecialchars($_SESSION['name']); ?></strong> (President)</p>
    <a href="logout.php" class="btn btn-danger mb-3">Logout</a>

    <?php if (!empty($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
    <?php if (!empty($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

    <?php if ($assigned_society === null): // If no society is assigned, display a message and no forms ?>
        <div class="alert alert-info">
            It looks like you are not currently assigned as a president to any society.
            Please contact an administrator to be assigned.
        </div>
    <?php else: // Proceed with forms and event listing if a society is assigned ?>
        <div class="alert alert-success">
            ✅ You are currently assigned as the president of the **<?php echo htmlspecialchars($assigned_society['name']); ?>** society.
        </div>

        <div class="card mb-4">
            <div class="card-header">Your Society Details</div>
            <div class="card-body">
                <h5 class="card-title"><?php echo htmlspecialchars($assigned_society['name']); ?></h5>
                <?php if (!empty($assigned_society['logo'])): ?>
                    <img src="images/<?php echo htmlspecialchars($assigned_society['logo']); ?>" class="img-fluid mb-3" alt="Society Logo" style="max-width: 150px;">
                <?php else: ?>
                    <p>No Logo Available</p>
                <?php endif; ?>
                <p class="card-text"><?php echo htmlspecialchars($assigned_society['description']); ?></p>
                <!-- Add more society-specific management options here -->
                <a href="manage_members.php?society_id=<?php echo $assigned_society['society_id']; ?>" class="btn btn-info">Manage Members</a>
                <!-- You can add links to manage events, announcements, etc. -->
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header">Add New Event</div>
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label>Event Title</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Description</label>
                        <textarea name="description" class="form-control" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label>Date</label>
                        <input type="date" name="date" class="form-control" required min="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="mb-3">
                        <label>Time</label>
                        <input type="time" name="time" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Venue</label>
                        <input type="text" name="venue" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Poster (Upload Image)</label>
                        <input type="file" name="poster" class="form-control" accept="image/jpeg, image/png, image/gif">
                    </div>
                    <button type="submit" name="add_event" class="btn btn-primary">Add Event</button>
                </form>
            </div>
        </div>

        <h4>Manage Events</h4>
        <?php if ($events && $events->num_rows > 0): ?>
            <div class="card mb-4">
                <div class="card-body">
                    <?php while ($event = $events->fetch_assoc()): ?>
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($event['title']); ?></h5>
                                <p class="card-text"><?php echo htmlspecialchars($event['description']); ?></p>
                                <p><strong>Date:</strong> <?php echo htmlspecialchars($event['date']); ?></p>
                                <p><strong>Time:</strong> <?php echo htmlspecialchars($event['time']); ?></p>
                                <p><strong>Venue:</strong> <?php echo htmlspecialchars($event['venue']); ?></p>
                                <?php if (!empty($event['poster'])): ?>
                                    <p><strong>Poster:</strong> <img src="images/<?php echo htmlspecialchars($event['poster']); ?>" width="100" alt="Event Poster"></p>
                                <?php endif; ?>
                                <p><strong>Status:</strong> <?php echo htmlspecialchars($event['status'] ?? 'Not Submitted'); ?></p>
                                <form method="POST" enctype="multipart/form-data" class="mt-2">
                                    <input type="hidden" name="event_id" value="<?php echo $event['event_id']; ?>">
                                    <div class="mb-3">
                                        <label>Update Title</label>
                                        <input type="text" name="title" class="form-control" value="<?php echo htmlspecialchars($event['title']); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Update Description</label>
                                        <textarea name="description" class="form-control" required><?php echo htmlspecialchars($event['description']); ?></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label>Update Date</label>
                                        <input type="date" name="date" class="form-control" value="<?php echo htmlspecialchars($event['date']); ?>" required min="<?php echo date('Y-m-d'); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label>Update Time</label>
                                        <input type="time" name="time" class="form-control" value="<?php echo htmlspecialchars($event['time']); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Update Venue</label>
                                        <input type="text" name="venue" class="form-control" value="<?php echo htmlspecialchars($event['venue']); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Update Poster (Upload New Image)</label>
                                        <input type="file" name="poster" class="form-control" accept="image/jpeg, image/png, image/gif">
                                    </div>
                                    <button type="submit" name="update_event" class="btn btn-warning">Update Event</button>
                                </form>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        <?php else: ?>
            <p>No events found for your society.</p>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php include("includes/footer.php"); ?>
