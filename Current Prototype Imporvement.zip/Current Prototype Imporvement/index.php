<?php include("includes/db_connect.php"); ?>
<?php include("includes/header.php"); ?>

<h2 class="mb-4">University Societies</h2>
<div class="row">
<?php
$stmt = $conn->prepare("SELECT * FROM societies");
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $logo_path = file_exists("images/" . $row['logo']) ? "images/" . $row['logo'] : "images/default.png";
        echo '<div class="col-md-4 mb-3">';
        echo '<div class="card">';
        echo '<img src="' . htmlspecialchars($logo_path) . '" class="card-img-top" alt="Society Logo">';
        echo '<div class="card-body">';
        echo '<h5 class="card-title">' . htmlspecialchars($row['name']) . '</h5>';
        echo '<p class="card-text">' . htmlspecialchars($row['description']) . '</p>';
        echo '<a href="society.php?id=' . $row['society_id'] . '" class="btn btn-primary">View Society</a>';
        echo '</div></div></div>';
    }
} else {
    echo "<p>No societies found.</p>";
}
$stmt->close();
?>
</div>

<?php include("includes/footer.php"); ?>