<?php
session_start();
include("includes/db_connect.php");

// Check if user is Member
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Member') {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_event'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $date = $_POST['date'];
    $time = $_POST['time'];
    $venue = $conn->real_escape_string($_POST['venue']);
    $poster = $_FILES['poster']['name'];
    $target = "images/" . basename($poster);

    // Validate date
    $today = date('Y-m-d');
    if ($date <= $today) {
        $error = "❌ Date must be in the future.";
    } else {
        // Check for duplicate event
        $stmt = $conn->prepare("SELECT * FROM events WHERE date = ?");
        $stmt->bind_param("s", $date);
        $stmt->execute();
        $check_result = $stmt->get_result();

        if ($check_result->num_rows > 0) {
            $error = "❌ An event is already scheduled on $date. Please select another date.";
        } else {
            // Validate file
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            if (in_array($_FILES['poster']['type'], $allowed_types) && $_FILES['poster']['size'] < 5000000) {
                if (move_uploaded_file($_FILES['poster']['tmp_name'], $target)) {
                    $stmt = $conn->prepare("INSERT INTO events (title, description, date, time, venue, poster, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("ssssssi", $title, $description, $date, $time, $venue, $poster, $_SESSION['user_id']);
                    if ($stmt->execute()) {
                        $event_id = $conn->insert_id;
                        $stmt = $conn->prepare("INSERT INTO event_requests (event_id, status) VALUES (?, 'Pending')");
                        $stmt->bind_param("i", $event_id);
                        $stmt->execute();
                        $success = "✅ Event request submitted successfully!";
                    } else {
                        $error = "❌ Error: " . $conn->error;
                    }
                } else {
                    $error = "❌ Failed to upload poster.";
                }
            } else {
                $error = "❌ Invalid file type or size. Use JPEG, PNG, or GIF (max 5MB).";
            }
        }
        $stmt->close();
    }
}

include("includes/header.php");
?>
<h2>Member Panel</h2>
<p>Welcome, <strong><?php echo $_SESSION['name']; ?></strong> (Member)</p>
<a href="logout.php" class="btn btn-danger mb-3">Logout</a>

<?php if (!empty($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
<?php if (!empty($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

<!-- Event Request Form -->
<div class="card mb-4">
    <div class="card-header">Submit Event Request</div>
    <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label>Event Title</label>
                <input type="text" name="title" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Description</label>
                <textarea name="description" class="form-control" required></textarea>
            </div>
            <div class="mb-3">
                <label>Date</label>
                <input type="date" name="date" class="form-control" required min="<?php echo date('Y-m-d'); ?>">
            </div>
            <div class="mb-3">
                <label>Time</label>
                <input type="time" name="time" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Venue</label>
                <input type="text" name="venue" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Poster (Upload Image)</label>
                <input type="file" name="poster" class="form-control" required>
            </div>
            <button type="submit" name="submit_event" class="btn btn-primary">Submit Request</button>
        </form>
    </div>
</div>
<?php include("includes/footer.php"); ?>