<?php
session_start();
include("includes/db_connect.php"); // Ensure this path is correct

// Initialize variables for notifications
$success = "";
$error = "";

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // CSRF Token Validation
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $error = "❌ Invalid CSRF token. Please try again.";
        // For production, consider logging this attempt or stricter handling.
    } else {
        // Sanitize and trim inputs
        $name = trim($conn->real_escape_string($_POST['name']));
        $email = trim($conn->real_escape_string($_POST['email']));
        $password_raw = $_POST['password']; // Get raw password for hashing
        $role = trim($conn->real_escape_string($_POST['role']));

        // Input Validation
        if (empty($name) || empty($email) || empty($password_raw) || empty($role)) {
            $error = "❌ All fields are required.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "❌ Invalid email format.";
        } elseif (strlen($password_raw) < 8) { // Recommended minimum password length
            $error = "❌ Password must be at least 8 characters long.";
        } else {
            // Hash the password securely
            $hashed_password = password_hash($password_raw, PASSWORD_DEFAULT);

            // Check if email already exists
            $stmt_check_email = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
            if ($stmt_check_email === false) {
                error_log("Prepare failed for email check: " . $conn->error);
                $error = "❌ An internal database error occurred. Please try again later.";
            } else {
                $stmt_check_email->bind_param("s", $email);
                $stmt_check_email->execute();
                $stmt_check_email->store_result();

                if ($stmt_check_email->num_rows > 0) {
                    $error = "❌ Email already registered. Please use a different email or log in.";
                }
                $stmt_check_email->close();
            }

            // If no errors so far, proceed with user registration
            if (empty($error)) {
                $insert_role = $role; // Default role for direct insertion
                $needs_approval = false;

                if ($role == "President" || $role == "Moderator") {
                    // Set default role as Student, and flag for elevated role request
                    $insert_role = "Student";
                    $needs_approval = true;
                }

                // Insert user into the 'users' table
                $stmt_insert_user = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");

                if ($stmt_insert_user === false) {
                    error_log("Prepare failed for user insertion: " . $conn->error); // Log the actual SQL error
                    $error = "❌ Account creation failed due to a database error. Please contact support.";
                } else {
                    $stmt_insert_user->bind_param("ssss", $name, $email, $hashed_password, $insert_role);
                    if ($stmt_insert_user->execute()) {
                        $user_id = $stmt_insert_user->insert_id;

                        if ($needs_approval) {
                            // Insert role request for Admin to approve
                            // IMPORTANT: Ensure 'role_requests' table does NOT have a 'president_id' column.
                            // It should only need user_id, requested_role, and status.
                            $request_stmt = $conn->prepare("INSERT INTO role_requests (user_id, requested_role, status) VALUES (?, ?, 'Pending')");
                            if ($request_stmt === false) {
                                error_log("Prepare failed for role request insertion: " . $conn->error);
                                $error = "❌ Account created, but role request failed. Please contact support.";
                            } else {
                                $request_stmt->bind_param("is", $user_id, $role); // Use the original requested role
                                if ($request_stmt->execute()) {
                                    $success = "✅ Account created! Your request for '$role' is pending admin approval.";
                                } else {
                                    $error = "❌ Account created, but role request failed: " . $request_stmt->error;
                                }
                                $request_stmt->close();
                            }
                        } else {
                            $success = "✅ Account created successfully!";
                        }
                    } else {
                        $error = "❌ Error creating account: " . $stmt_insert_user->error;
                    }
                    $stmt_insert_user->close();
                }
            }
        }
    }
}

// Regenerate CSRF token for the next request (or if the form is re-displayed due to error)
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

include("includes/header.php"); // Ensure this path is correct
?>
<div class="container mt-5">
    <div class="card p-4 mx-auto" style="max-width: 500px;">
        <h2 class="text-center mb-4">👤 Signup</h2>
        <?php if (!empty($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
        <?php if (!empty($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">

            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" name="name" id="name" class="form-control" required value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" id="email" class="form-control" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="role" class="form-label">Role</label>
                <select name="role" id="role" class="form-select" required>
                    <option value="">-- Select Role --</option>
                    <option value="Student" <?php echo (($_POST['role'] ?? '') == 'Student') ? 'selected' : ''; ?>>Student</option>
                    <option value="President" <?php echo (($_POST['role'] ?? '') == 'President') ? 'selected' : ''; ?>>President (Apply)</option>
                    <option value="Moderator" <?php echo (($_POST['role'] ?? '') == 'Moderator') ? 'selected' : ''; ?>>Moderator (Apply)</option>
                    <!-- <option value="Admin" <?php echo (($_POST['role'] ?? '') == 'Admin') ? 'selected' : ''; ?>>Admin (Direct Creation)</option> -->
                </select>
            </div>

            <button type="submit" class="btn btn-primary w-100">Signup</button>
            <p class="text-center mt-3">Already have an account? <a href="login.php">Login</a></p>
        </form>
    </div>
</div>
<?php include("includes/footer.php"); ?>
