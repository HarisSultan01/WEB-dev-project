<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "university_societies";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    header("Location: error.php?msg=" . urlencode("Connection failed: " . $conn->connect_error));
    exit();
}
?>