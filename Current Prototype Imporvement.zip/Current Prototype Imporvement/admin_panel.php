<?php
session_start();
include("includes/db_connect.php");

// ✅ Check if user is Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: login.php");
    exit();
}

// Variables for notifications
$success = $error = "";

// ✅ Add new society
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_society'])) {
    $name = trim($conn->real_escape_string($_POST['name']));
    $description = trim($conn->real_escape_string($_POST['description']));
    $president_id = intval($_POST['president_id']); // selected president
    $logo = $_FILES['logo']['name'];
    $target = "images/" . basename($logo);

    // Validate and upload logo
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    if (!empty($logo) && in_array($_FILES['logo']['type'], $allowed_types) && $_FILES['logo']['size'] < 5000000) {
        if (!move_uploaded_file($_FILES['logo']['tmp_name'], $target)) {
            $error = "❌ Failed to upload logo.";
        }
    } else {
        $logo = null;
    }

    if (empty($error)) {
        $sql = "INSERT INTO societies (name, logo, description, president_id) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("❌ Prepare failed: " . $conn->error);
        }
        $stmt->bind_param("sssi", $name, $logo, $description, $president_id);
        if ($stmt->execute()) {
            $success = "✅ Society added successfully.";
        } else {
            $error = "❌ Error adding society: " . $stmt->error;
        }
        $stmt->close();
    }
}

// ✅ Delete society
if (isset($_GET['delete'])) {
    $society_id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM societies WHERE society_id = ?");
    $stmt->bind_param("i", $society_id);
    if ($stmt->execute()) {
        $success = "✅ Society deleted successfully.";
    } else {
        $error = "❌ Error deleting society: " . $stmt->error;
    }
    $stmt->close();
}

// ✅ Fetch all societies
$societies_query = "SELECT s.*, u.name as president_name FROM societies s LEFT JOIN users u ON s.president_id = u.user_id";
$societies_result = $conn->query($societies_query);

// ✅ Fetch all users who can be assigned as President
$presidents_query = "SELECT user_id, name FROM users WHERE role='President'";
$presidents_result = $conn->query($presidents_query);

// ✅ Fetch pending role requests
$requests_query = "SELECT rr.*, u.name as user_name, u.email FROM role_requests rr JOIN users u ON rr.user_id = u.user_id WHERE rr.status = 'Pending'";
$requests_result = $conn->query($requests_query);

?>

<?php include("includes/header.php"); ?>
<div class="container mt-4">
    <h2>🎓 Admin Panel</h2>
    <p>Welcome, <strong><?php echo htmlspecialchars($_SESSION['name']); ?></strong> (Admin)</p>
    <a href="logout.php" class="btn btn-danger mb-3">Logout</a>

    <!-- Success and Error Messages -->
    <?php if (!empty($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
    <?php if (!empty($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

    <!-- Add Society Form -->
    <div class="card mb-4">
        <div class="card-header">Add New Society</div>
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label>Society Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Description</label>
                    <textarea name="description" class="form-control" required></textarea>
                </div>
                <div class="mb-3">
                    <label>Logo (Upload Image)</label>
                    <input type="file" name="logo" class="form-control">
                </div>
                <div class="mb-3">
                    <label>Assign President</label>
                    <select name="president_id" class="form-select" required>
                        <option value="">-- Select President --</option>
                        <?php while ($president = $presidents_result->fetch_assoc()): ?>
                            <option value="<?php echo $president['user_id']; ?>">
                                <?php echo htmlspecialchars($president['name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <button type="submit" name="add_society" class="btn btn-primary">Add Society</button>
            </form>
        </div>
    </div>

    <!-- Role Request Inbox -->
    <div class="card mb-4">
        <div class="card-header">📥 Role Request Inbox</div>
        <div class="card-body">
            <?php if ($requests_result->num_rows > 0): ?>
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Request ID</th>
                            <th>User Name</th>
                            <th>User Email</th>
                            <th>Requested Role</th>
                            <th>Request Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($request = $requests_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $request['request_id']; ?></td>
                                <td><?php echo htmlspecialchars($request['user_name']); ?></td>
                                <td><?php echo htmlspecialchars($request['email']); ?></td>
                                <td><?php echo htmlspecialchars($request['requested_role']); ?></td>
                                <td><?php echo htmlspecialchars($request['request_date']); ?></td>
                                <td>
                                    <a href="handle_request.php?action=approve&request_id=<?php echo $request['request_id']; ?>"
                                       class="btn btn-success btn-sm me-2"
                                       onclick="return confirm('Are you sure you want to approve this request?');">Approve</a>
                                    <a href="handle_request.php?action=reject&request_id=<?php echo $request['request_id']; ?>"
                                       class="btn btn-danger btn-sm"
                                       onclick="return confirm('Are you sure you want to reject this request?');">Reject</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-info">No pending role requests.</div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Existing Societies List -->
    <h4>📜 Existing Societies</h4>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Logo</th>
                <th>Name</th>
                <th>Description</th>
                <th>President</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $societies_result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['society_id']; ?></td>
                    <td>
                        <?php if (!empty($row['logo'])): ?>
                            <img src="images/<?php echo htmlspecialchars($row['logo']); ?>" width="50">
                        <?php else: ?>
                            <span>No Logo</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php htmlspecialchars($row['description']); ?></td>
                    <td><?php echo htmlspecialchars($row['president_name'] ?? "Not Assigned"); ?></td>
                    <td>
                        <a href="?delete=<?php echo $row['society_id']; ?>" 
                           class="btn btn-danger btn-sm" 
                           onclick="return confirm('Are you sure to delete this society?');">
                           Delete
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
<?php include("includes/footer.php"); ?>
